magick.css is an optimized version of Twitters bootstrap.css.
